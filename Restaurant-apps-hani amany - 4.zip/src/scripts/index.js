import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';

// Fungsi untuk toggle menu hamburger
const hamburger = document.getElementById('hamburger');
const navbarMenu = document.getElementById('navbar-menu');

hamburger.addEventListener('click', () => {
  navbarMenu.classList.toggle('open');
});

// Fetch data dari file JSON dan tampilkan di halaman
fetch('./data/DATA.json')
  .then(response => response.json())
  .then(data => {
    const restaurantList = document.getElementById('restaurant-list');
    data.restaurants.forEach(restaurant => {
      const listItem = document.createElement('li');
      listItem.classList.add('restaurant-card');
      
      listItem.innerHTML = `
        <div class="restaurant-image-container">
          <div class="restaurant-city-label">${restaurant.city}</div>
          <img src="${restaurant.pictureId}" alt="${restaurant.name}">
        </div>
        <div class="restaurant-rating">Rating: ${restaurant.rating}</div>
        <h3>${restaurant.name}</h3>
        <p class="restaurant-description">${restaurant.description}</p>
      `;
      
      restaurantList.appendChild(listItem);
    });
  })
  .catch(error => console.error('Error fetching restaurant data:', error));
